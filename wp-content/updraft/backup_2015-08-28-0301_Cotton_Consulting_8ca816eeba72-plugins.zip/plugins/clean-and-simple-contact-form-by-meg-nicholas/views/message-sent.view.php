<h3><?php echo $heading; ?></h3>
<p><?php echo $message; ?> </p>