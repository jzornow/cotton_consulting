scnShortcodeMeta={
	attributes:[
		{
			label:"Image source",
			id:"content",
			isRequired:true
		},
		{
			label:"Style",
			id:"style",
			help:"",
            controlType:"select-control", 
			selectValues:['rounded', 'circle', 'polaroid']
        }
        
		],
		
		shortcode:"imagestyle"
};