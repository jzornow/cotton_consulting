scnShortcodeMeta={
	attributes:[
	
		{
			label:"Background",
			id:"background",
			help:"If you don't set color the blockquote will be showed only with border",
			
        }
		],
		defaultContent: "Add your text here",
		shortcode:"blockquote"
};